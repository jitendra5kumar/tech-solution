import React from 'react';
import "./hero.css"
import IMG1 from "../esset/img2.jpg"
import IMG2 from "../esset/img3.jpg"

const Hero = () => {
    return (
        <>
            <div className="container1">

                <div className="container">

                    <div className="main-tringle">
                        <div className="nav">
                            <div className="logo">Logo</div>

                            <div className="about">
                                <p>About</p>
                                <p>Pricing</p>
                                <p>Review</p>
                            </div>
                        </div>
                        <div className="hero">
                            <div className="content">
                                <h1>Learn how to launch a successful podcast</h1>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quasi possimus veritatis atque maiores, est quae eveniet neque facere, ipsam delectus repellat sapiente nostrum soluta! Suscipit natus officiis</p>
                                <button>Sign Up Now</button>
                            </div>
                            <div className="img">
                                <div className="pic">
                                    <img src={IMG1} className='img1' alt="" />
                                    <img src={IMG2} className='img2' alt="" />
                                    <ul>
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                        <li></li>

                                    </ul>
                                </div>
                                <div className="dot">
                                    <ul>
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div className="circle">

                        </div>
                        <div className="parallelogram"></div>
                    </div>
                </div>

                <br />
                <div className="feature">
                    <div className="feature-interactive">
                        <div className="interactive1">
                            <div className="int">
                                <h3>Interactive features</h3>
                                <p>Lorem ipsum dolor sit, amet dummy consectetur adipisicing elit. hence, Recusandae beatae iure autem,</p>
                            </div>
                            <div className="int">
                                <h3>Interactive features</h3>
                                <p>Lorem ipsum dolor sit, amet dummy consectetur adipisicing elit. hence, Recusandae beatae iure autem,</p>
                            </div>
                        </div>
                        <div className="interactive2">
                            <div className="int">
                                <h3>Interactive features</h3>
                                <p>Lorem ipsum dolor sit, amet dummy consectetur adipisicing elit. hence, Recusandae beatae iure autem,</p>
                            </div>
                            <div className="int">
                                <h3>Interactive features</h3>
                                <p>Lorem ipsum dolor sit, amet dummy consectetur adipisicing elit. hence, Recusandae beatae iure autem,</p>
                            </div>
                        </div>
                    </div>
                    <div className="feature-about">
                        <h1>About the course</h1>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit soluta, eius ullam iste quam similique, quis molestias commodi fuga, sapiente velit. Nisi praesentium eos sequi quos.</p>
                        <button>Explore Now</button>
                    </div>
                </div>
            </div>
        </>
    );
};



export default Hero;